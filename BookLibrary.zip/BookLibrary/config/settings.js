module.exports = {
    development: {
        port: 1337,
        db: 'mongodb://localhost:27017/booklibraryexer'
    }
}