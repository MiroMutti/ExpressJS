module.exports = {
    development: {
        //'mongodb://mpa:mpampa1@ds016718.mlab.com:16718/mongoplayground'
        connectionString: 'mongodb://localhost:27017/MongoPlaygroundApp',
        production: {}
    }
}